package ru.ifmo.rain.naumov.parser;

public enum Token {
    OPENING, CLOSING, CONJUNCTION, DISJUNCTION, IMPLICATION, VARIABLE, NEGATION, END
}
